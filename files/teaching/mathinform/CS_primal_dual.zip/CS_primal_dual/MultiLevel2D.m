
%[row,col] : size of sampling map
%k: number of samples to draw (with replacement)
%c: frequencies to include up to
%Lev: number of samples
function [samples, total] = MultiLevel2D(row,col, k, a,b, c, Lev)


[xInd,yInd] = meshgrid(-col/2+1:col/2,-row/2+1:row/2);
cInd = xInd+1i*yInd;
N = max(abs(cInd(:)));

w = exp(-(b*ceil(abs(cInd)*Lev/N)/Lev).^a);
w = w(:);
samples = randsample(row*col,k,true,w);

centre = find(sqrt(xInd.^2+yInd.^2)<=c);
samples =  unique([samples;centre]);
total = length(samples);
end

