% N: input size is NxN
% J: number of levels of decomposition
% wname: type of wavelet available via Matlab's wavelet toolbox
% Returns: the forward f and inverse TRANSLATION INVARIANT WAVELET transform t.
%
% Author: Clarice Poon

function [f,t] = TIWavfunc( N, J, wname)

l = N^2*J;

f = @(x)  forward(x,J,wname);
t = @(x) transpose(x,N,J,l,wname);

end





function coeff = forward(x,J,wname)
    [A,H,V,D]  = swt2(real(x),J,wname);
    [Ai,Hi,Vi,Di]  = swt2(imag(x),J,wname);
    coeff =[A(:)+1i*Ai(:); H(:)+1i*Hi(:); V(:)+1i*Vi(:); D(:)+1i*Di(:)];   
end


function y = transpose(x,N,J,l,wname)   
    A = reshape(x(1:l), N,N,J);
    H = reshape(x(1+l:2*l), N,N,J);
    V = reshape(x(1+2*l:3*l), N,N,J);
    D = reshape(x(1+3*l:end), N,N,J);
     
    wc = iswt2(real(A),real(H),real(V),real(D), wname);
    wci = iswt2(imag(A),imag(H),imag(V),imag(D), wname);
    y = wc + 1i*wci;
end

