%%This script solves min_x ||Wx||_1+ (lambda/2)*||Fx -b||_2^2
% where F is a subsampled Fourier operator and b are the given measurements
% We implement the primal dual algorithm of Chambolle and Pock, see the matlab script on tv
% inpainting for more details on the primal dual approach
%
% Author: Clarice Poon


close all
clearvars
%% Load a test image
% g = imread('images/2048_text.png');
g= phantom(512);
g=double(g);
g = g/max(g(:));
[m,n]=size(g);
N = 2^floor(log2(min(m,n)));
g = g(1:N,1:N); % for simplicity, work with images of size 2^Jx2^J

noise = rand(size(g));
sigma = 0.05*norm(g(:));
g = g+ sigma*noise/norm(noise(:));

figure, imagesc(g), colormap(gray), axis square



%% Define a sampling mask
masktype = 'radial';
s= 0.2; %subsampling ratio, between 0 and 1.

mask = zeros(N);
switch masktype
    case 'radial'
        [xInd,yInd] = meshgrid(-floor(N/2):floor(N/2)-1,-floor(N/2):floor(N/2)-1);
        
        L=ceil(s*N);
        for k=1:L
            ang = k*pi/L;
            mask(yInd==round(xInd*cot(ang)))=1;
            mask(xInd==round(yInd*tan(ang)))=1;
        end
    case 'powerlaw'
        [xInd,yInd] = meshgrid(-floor(N/2):floor(N/2)-1,-floor(N/2):floor(N/2)-1);
        w = 1./max(1,(abs(xInd).^3+abs(yInd).^3));
        draw = ceil(s*N^2);
        while sum(mask(:))<ceil(s*N^2)
            samp = randsample(N^2,draw,true,w(:));
            w(samp)=0;
            mask(samp)=1;
            draw = ceil(s*N^2) - sum(mask(:));
        end
        
    case 'multilev'
        k = ceil(s*N^2);
        a = 2; 
        b= 3;
        c=50;
        [samples, total] = MultiLevel2D(N,N, k, a,b, c, 10);

        mask(samples) = 1;
    case 'uniform'
        ord = randperm(N^2);
        mask(ord(1:ceil(s*N^2))) = 1;
        mask(1,1) = 1; %include 0th fourier frequency
        
    case 'lowfreq'
        [xInd,yInd] = meshgrid(-floor(N/2):floor(N/2)-1,-floor(N/2):floor(N/2)-1);
        
        p=ceil(sqrt(s*N^2/4));
        mask(max(abs(xInd),abs(yInd))<p)=1;
        
        
end
imagesc(mask); title('sampling mask'); axis square
mask = ifftshift(mask);

%Fourier samples
b = mask.*(fft2(g))/N;





%% Apply the primal dual algorithm
% see http://www.damtp.cam.ac.uk/user/cmhsp2/teaching/tvinpainting.html
% We solve min_x F(Ax) + G(x)
% where A is the regularizer, F(x) = |x|_1, G(x) = lambda/2 |K x - b |_2^2 
% where K is the partial Fourier operator.
%
% Define the proximal operators:
lambda = 500;
Prox_Gtau =  @(z,tau) N*ifft2((fft2(z)/N + tau*lambda*b)./(1+ tau*lambda*mask));

Prox_F = @(sigma, z) sign(z).*(abs(z)-sigma).*(abs(z)>=sigma) ;
Prox_FS = @(sigma,z) z-sigma*Prox_F(1/sigma, z/sigma);
%%
% Define the forward and transpose regularization operators:

regularizer = 'curvelet';
switch regularizer
    case 'iso_tv'
        %isotropic total variation
        W = @(f) [f - circshift(f,1,1) ,f - circshift(f,1,2)];
        Wt = @(f) (f(:, 1:N)- circshift(f(:, 1:N),-1,1) ) ...
            +(f(:,N+1:end)-circshift(f(:,N+1:end),-1,2));
        
        %need to redefine Proximal operator
        abs2 = @(z) repmat( sqrt(abs(z(:,1:n)).^2 +abs(z(:,1+n:end)).^2), 1,2);
        sign2 = @(z) [real(sign(z(:,1:n)+1i*z(:,1+n:end))), imag(sign(z(:,1:n)+1i*z(:,1+n:end)))];
        Prox_F = @(sigma, z) sign2(z).*(abs2(z)-sigma).*(abs2(z)>=sigma) ;
        Prox_FS = @(sigma,z) z-sigma*Prox_F(1/sigma, z/sigma);
        
        Prox_FS2 = @(sigma,z) z./max(1,abs2(z));
        norm_bd =4;
        
    case 'aniso_tv'
        %anisotropic total variation
        W = @(f) [f - circshift(f,1,1) ,f - circshift(f,1,2)];
        Wt = @(f) (f(:, 1:N)- circshift(f(:, 1:N),-1,1) ) ...
            +(f(:,N+1:end)-circshift(f(:,N+1:end),-1,2));
        norm_bd =4;
        
    case 'on_wavelet'
        %%orthogonal wavelet, needs matlab wavelet toolbox
        w_type = 'db2'; % or 'db2', etc
        [W,Wt] = Wavfunc( N, w_type);
        norm_bd = 12;
        %
    case 'ti_wavelet'
        %%translation invariant wavelet, needs matlab wavelet toolbox
        [W,Wt] = TIWavfunc( N, 3, 'haar');
        
        %
    case 'curvelet'
        %curvelet, needs Curvelab, http://www.curvelet.org/software.html
        [W,Wt] = Curvfunc( N);
        
end

%%
if ~exist('norm_bd', 'var')
    [N1,N2] = size(W(zeros(N)));
    vec = @(x) x(:);
    S = @(x) vec( W(reshape(x,N,N)));
    St = @(x) vec(Wt(reshape(x,N1,N2)));
    [norm_bd,~] = my_normest(S,St,N^2,1e-6, 200);
    norm_bd = ceil(norm_bd);
end
%%
% Define the primal dual iterations:

x =zeros(N);
xi = W(zeros(N));
xbar = zeros(N);
%%
normj = @(x,j) norm(x(:),j);



maxit = 4000;
sigma = 2; tau=.7/sigma/norm_bd^2; 
theta=1;
Prox_G = @(z) Prox_Gtau(z,tau);
energy = zeros(maxit,1);
updatefig = figure('Position', [100, 100, 800, 400]); colormap('gray')
hw = waitbar(0, 'Wait', 'CreateCancelBtn', {@(H,~) delete( findobj( get(H,'Parent'), '-Depth', 1, 'Tag', 'TMWWaitbar'))});
for it = 1:maxit
    xi = Prox_FS(sigma, xi +sigma*W(xbar));
    xold = x;
    x = Prox_G(x-tau*Wt(xi));
    xbar = x+theta*(x-xold);
    
    energy(it) = normj(W(x),1) +0.5* lambda*normj(mask.*fft2(x)/N - b,2)^2;
    
    if ~mod(it, 1)
        figure(updatefig), subplot(1,2,1), semilogy(energy(1:it));
        subplot(1,2,2), imagesc(real(x), [0,1]); 
        pause(0.01)
        
    end
    try
        waitbar(it/maxit,hw, sprintf('iteration:%d',it))
    catch
        break
    end
    
end
delete(hw);
%%
% Display the output:

figure()
imagesc(real(x),[0 1]); colormap('gray'); axis square
