% N: input size is NxN
% wname: type of wavelet available via Matlab's wavelet toolbox
% Returns: the forward f and inverse ORTHOGONAL WAVELET transform t.
%
% Author: Clarice Poon

function [f,t] = Wavfunc( N, wname)

J = floor(log2(N));
[~,S ]= wavedec2(zeros(N),J,wname);

f = @(x) forward(x,J,wname);
t = @(x) transpose(x,S,wname);

end

function coeff = forward(x,J,wname)
    [coeff_r,~]  = wavedec2(real(x),J,wname);  
    [coeff_i,~]  = wavedec2(imag(x),J,wname); 
    coeff = coeff_r + 1i*coeff_i;

end


function x = transpose(coeff,S,wname)
    x = waverec2(real(coeff),S, wname) + 1i* waverec2(imag(coeff),S, wname);
end
