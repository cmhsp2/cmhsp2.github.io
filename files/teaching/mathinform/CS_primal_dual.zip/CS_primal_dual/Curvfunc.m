% N: input size is NxN
% Returns: the forward f and inverse CURVELET transform t.
%
% Requires Curvelab: http://www.curvelet.org/software.html
%
% Author: Clarice Poon

function [f,t] = Curvfunc(N)

    C = fdct_wrapping(zeros(N),1,1);
    f = @(x) forward(x,N);
    t = @(x) transpose(x,C,N);

end


function coeff = forward(x,N)
    C = fdct_wrapping(x,1,1);
    coeff = [];
    for s=1:length(C)
        for w=1:length(C{s})
            coeff = [coeff; C{s}{w}(:)];
        end
    end
end


function x = transpose(x,C,N)
    l=1;
    for s=1:length(C)
        for w=1:length(C{s})
            [s1,s2] = size(C{s}{w});
            C{s}{w} = reshape(x(l:l+s1*s2-1),s1,s2);
            l=s1*s2+l;
        end
    end
    x = ifdct_wrapping(C,1,N,N);
end



