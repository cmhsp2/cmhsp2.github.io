This folder contains the filters for the boundary wavelets introduced in the following paper.

A. Cohen, I. Daubechies, and P. Vial, Wavelets on the interval and fast wavelet transforms, Appl. Comp. Harm. Anal., 1 (1), pp. 54-81, 1993. 

These filters were downloaded from 
http://www.pacm.princeton.edu/~ingrid/publications/54.txt