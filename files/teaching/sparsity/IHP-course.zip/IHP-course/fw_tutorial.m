%demonstrates Frank-Wolfe in 1D for Fourier measurements

clearvars 
close all

addpath('toolbox/');
addpath('lbfgsb/');

a_true = [2 2 3 -5]'; %true amplitudes
X_true = [0.1, 0.13, 0.6, 0.67]; %true positions

lambda = 0.05; %regularisation parameter

%add noise
Xn = rand(1,20);
an = 1e-2*(rand(1,20)-0.5)';

a0 = [a_true;an];
X0 = [X_true,Xn];


%measurement operator
fc = 10;
freq = (-fc:fc)';
% freq = randi(fc,15,1)-fc;

vrt = @(x) x(:);
Phi =@(x) exp(2*pi*1i*vrt(freq)*vrt(x).')/sqrt(2*fc+1);
dPhi =@(x) diag(2*pi*1i*freq)*exp(2*pi*1i*vrt(freq)*vrt(x).')/sqrt(2*fc+1);

%kernel
%C = Phi_U'*(Phi_X*a) is a vector of size U
C = @(U,X) (Phi(U))'*Phi(X);
%dC = (Phi_U)^{(1)}'*(Phi_X*a) is a vector of size U
dC = @(U,X) (dPhi(U))'*Phi(X);



u = linspace(0,1,1000); %parameter search space


%% Observation
figure(10);
clf;
obs = C(u,X0)*a0;
plot(u,real(obs));
hold on
stem(X_true,a_true, 'r')



%% vanishing derivatives certificate
S = [sign(a_true); zeros(length(a_true),1)];
ddC = @(U,X) (dPhi(U))'*dPhi(X);
Cd = @(U,X) (Phi(U))'*dPhi(X);

M = [C(X_true,X_true), Cd(X_true,X_true); ...
    (Cd(X_true,X_true))', ddC(X_true,X_true)];
coeffs = (M\S);
etaV = [C(u,X_true), Cd(u,X_true)]*coeffs;

%display
figure(11); clf
plot(u,real(etaV));
hold on
stem(X_true, sign(a_true), 'r');
title('\eta_V')



%% perform ISTA
%solve min_a lambda* |a|_1 + 1/2 * |Phi_u * a - Phi_u * a0 |_2

do_ista = 1;
figure(12);

if do_ista
    
    gamma = 1/norm(C(u,u)); %stepsize
    maxit = 200;
    
    
    ai = zeros(size(u)).';
    for it=1:maxit
        ai = ai +gamma* (C(u,X0)*a0 -C(u,u)*ai);
        ai = wthresh(ai,'s',gamma*lambda);
        
        if mod(10,it)
            stem(u,real(ai));
            drawnow
        end
    end
end

%% perform Frank-Wolfe
%
do_noncvx = 1; %include nonconvex update?
%inputs for LBFGS
% E(x,a) = 1/2*|Phi(x)*a - y|^2 + lambda* |a|_1
%   nabla_a E(x,a) =  Phi(x)' * (Phi(x)*a-y) + lambda
%                  = [ C(x,x)*a-C(x,x0)*a0 ] + lambda
%   nabla_x E(x,a) =  diag(a)*Phi'(x)' * (Phi(x)*a-y)
%                  =  a .* [ CD(x,x)*a-CD(x,x0)*a0 ]
op.nablaEx = @(x,a,x0,a0,lambda) diag(a) * ( dC(x,x)*a- dC(x,x0)*a0);
op.nablaEa = @(x,a,x0,a0,lambda) ( C(x,x)*a- C(x,x0)*a0 ) +lambda* sign(a);
op.E = @(x,a,x0,a0,lambda)1/2*norm(Phi(x)*a-Phi(x0)*a0)^2 +lambda* norm(a,1);


maxit = 150; %max number of Frank-Wolfe iterations
ista_maxit = 300; %max number of interal ISTA iterations
a = [];
X = [];

figure(21); clf
for k=1:maxit
       
    if ~isempty(a)
        etak = (C(u,X0)*a0 - C(u,X)*a)/lambda;
    else
        etak = C(u,X0)*a0/lambda;
    end
        
    %display
    subplot(1,2,1)
    stem(X,real(a));
    subplot(1,2,2)
    plot(u,real(etak));
    drawnow
       
    %add new spike, I simply search for largest abs value on grid here, but
    %you could add a local ascent step
    [v,pos] = max(abs(etak));
    xnew = u(pos);
    if v<1+1e-5
        break
    end
    a = [a; etak(pos)];
    X = [X,xnew];
        
    %perform ISTA to optimise amplitudes
    ai = a;
    gamma = 1/norm(C(X,X));
    for it=1:ista_maxit
        ai = ai +gamma* (C(X,X0)*a0 -C(X,X)*ai);
        ai = wthresh(ai,'s',gamma*lambda);
    end
    a = ai;
       
    %simulaneously optimise amplitudes and pos.
    if do_noncvx
        [X,a,R] = noncvx_sparse_spikes(op,lambda, X0,a0, X,a, {});
        X = X(:).';        
    end   
    
end

%% display result

%group the close spikes
ind = find(abs(a)>1e-8);
a_tmp = a(ind);
X_tmp = X(ind);
[X_tmp,i1, i2] = uniquetol(X_tmp,1e-4);
a2 = zeros(size(X_tmp));
for j=1:length(X_tmp)
    ind = i2==j;
    a2(j) = sum(a_tmp.*ind);
end
X2 = X_tmp;

%plot
figure(21);
subplot(1,2,1)
stem(X2,real(a2));
xlim([0,1])
title('recovered measure');
subplot(1,2,2)
plot(u,real(etak));
title('\eta_k')
