%demonstrates Frank-Wolfe in 2D for Fourier measurements

clearvars 
close all

addpath('toolbox/');
addpath('lbfgsb/');

a_true = [.2 .2 .3]'; %true amplitudes
X_true1 = [0.1, 0.13, 0.6]; %true positions
X_true2 = [0.1, 0.15, 0.3]; %true positions

%add noise
Xn1 = rand(1,20);
Xn2 = rand(1,20);
an = 1e-2*(rand(1,20)-0.5)';

lambda = 0.05; %regularisation parameter

a0 = [a_true;an];
X01 = [X_true1,Xn1];
X02 = [X_true2,Xn2];

fc = 8;
freq1d = (-fc:fc)';

[freq1,freq2] = meshgrid(freq1d,freq1d);

vrt = @(x) x(:);
Phi =@(x1,x2) exp(2*pi*1i*(vrt(freq1)*vrt(x1).'+vrt(freq2)*vrt(x2).'))/(2*fc+1);
d1Phi =@(x1,x2) diag(2*pi*1i*freq1(:)) * Phi(x1,x2); %deriv wrt 1st variable
d2Phi =@(x1,x2) diag(2*pi*1i*freq2(:))* Phi(x1,x2); %deriv wrt 2nd variable
dPhi = @(u1,u2) [d1Phi(u1,u2),d2Phi(u1,u2)];

%The kernel
%C = Phi_U'*Phi_X is a matrix of size |U|\times |X|
C = @(U1,U2,X1,X2) (Phi(U1,U2))'*Phi(X1,X2);
%dC = (Phi_U)^{(1)}'*Phi_X is a matrix of size |U|\times |X|
dC = @(U1,U2,X1,X2) (dPhi(U1,U2))'*Phi(X1,X2);

N = 50;
u = linspace(0,1,N); %search space
[u1,u2] = meshgrid(u,u);

%% Observation
figure(1);
clf;
obs = C(u1,u2,X01,X02)*a0;
imagesc(reshape(real(obs),N,N));

indp = find(a_true>0);
indn = find(a_true<0);
hold on

plot(X_true1(indp), X_true2(indp), 'r*', 'LineWidth', 2, 'MarkerSize', 3);
plot(X_true1(indn), X_true2(indn), 'g*', 'LineWidth', 2, 'MarkerSize', 3);



%% vanishing derivatives certificate
S = [sign(a_true); zeros(length(a_true)*2,1)];
ddC = @(U1,U2,X1,X2) (dPhi(U1,U2))'*dPhi(X1,X2);
Cd = @(U1,U2,X1,X2) (Phi(U1,U2))'*dPhi(X1,X2);

Gamma = [C(X_true1,X_true2,X_true1,X_true2), Cd(X_true1,X_true2,X_true1,X_true2); ...
    (Cd(X_true1,X_true2,X_true1,X_true2))', ddC(X_true1,X_true2,X_true1,X_true2)];
coeffs = (Gamma\S);
etaV = [C(u1,u2,X_true1,X_true2), Cd(u1,u2,X_true1,X_true2)]*coeffs;
figure(10); clf
imagesc(u,u,reshape(real(etaV),N,N));
hold on


plot(X_true1(indp), X_true2(indp), 'r*', 'LineWidth', 2, 'MarkerSize', 3);
plot(X_true1(indn), X_true2(indn), 'g*', 'LineWidth', 2, 'MarkerSize', 3);

title('\eta_V')



%% perform ISTA
%solve min_a lambda* |a|_1 + 1/2 * |Phi_u * a - Phi_u * a0 |_2

do_ista = 1;
figure(11);
if do_ista
    gamma = 1/norm(C(u1,u2,u1,u2)); %stepsize
    maxit = 50;
    ai = zeros(numel(u1),1);
    for it=1:maxit
        ai = ai +gamma* (C(u1,u2,X01,X02)*a0 -C(u1,u2,u1,u2)*ai);
        ai = wthresh(ai,'s',gamma*lambda);
        
        if mod(10,it)
            surf(u,u,real(reshape(ai,N,N)));
            drawnow
        end
    end
end

%%
%perform Frank-Wolfe
do_noncvx = 1; %include nonconvex update?
% inputs for LBFGS
% E(x,a) = 1/2*|Phi(x)*a - y|^2 + lambda* |a|_1
%   nabla_a E(x,a) =  Phi(x)' * (Phi(x)*a-y) + lambda
%                  = [ C(x,x)*a-C(x,x0)*a0 ] + lambda
%   nabla_x E(x,a) =  diag(a)*Phi'(x)' * (Phi(x)*a-y)
%                  =  a .* [ CD(x,x)*a-CD(x,x0)*a0 ]
H1 = @(x)x(1:end/2);
H2 = @(x)x(end/2+1:end);
op.nablaEx = @(x,a,x0,a0,lambda) repmat(a,[2 1]) .*  ( dC(H1(x),H2(x),H1(x),H2(x))*a- dC(H1(x),H2(x),H1(x0),H2(x0))*a0);
op.nablaEa = @(x,a,x0,a0,lambda) ( C(H1(x),H2(x),H1(x),H2(x))*a- C(H1(x),H2(x),H1(x0),H2(x0))*a0 ) +lambda* sign(a);
op.E = @(x,a,x0,a0,lambda)1/2*norm(Phi(H1(x),H2(x))*a-Phi(H1(x0),H2(x0))*a0)^2 +lambda* norm(a,1);


maxit = 150; %number of outer FW iterations
ista_maxit = 300; %number of inner ISTA iterations
a = [];
X1 = [];
X2 = [];
figure(21); clf
for k=1:maxit
    
    if ~isempty(a)
        etak = (C(u1,u2,X01,X02)*a0 - C(u1,u2,X1,X2)*a)/lambda;
    else
        etak = C(u1,u2,X01,X02)*a0/lambda;
    end
    
    %display
    subplot(1,2,1)
    stem3(X1,X2,real(a), 'Linewidth', 2);
    subplot(1,2,2)
    imagesc(u,u,real(reshape(etak,N,N)));
    drawnow
    
    %add new spike, I simply search for largest abs value on a grid here, but
    %you could add a local ascent step
    [eta_max,pos] = max(abs(etak));
    xnew1 = u1(pos);
    xnew2 = u2(pos);
    anew = etak(pos);
    
    if eta_max<1+1e-5
        break
    end
    a = [a; anew];
    X1 = [X1,xnew1];
    X2 = [X2,xnew2];
    
    %perform ISTA to optimise amplitudes
    ai = a;
    gamma = 1/norm(C(X1,X2,X1,X2));
    for it=1:ista_maxit
        ai = ai +gamma* (C(X1,X2,X01,X02)*a0 -C(X1,X2,X1,X2)*ai);
        ai = wthresh(ai,'s',gamma*lambda);
    end
    a = ai;
    
    %simulaneously optimise amplitudes and pos.
    X0a = [X01(:);X02(:)];
    Xa = [X1(:); X2(:)];
    if do_noncvx
        [X,a,R] = noncvx_sparse_spikes(op,lambda, X0a,a0, Xa,a, {});
        X = X(:).';
        X1 = X(1:end/2); X2 = X(end/2+1:end);
    end
end



%% remove the small spikes
ind = find(abs(a)>1e-8);
a2 = a(ind);
X1 = X1(ind);
X2 = X2(ind);


%% display result

figure(31); clf
imagesc(u,u,real(reshape(etak,N,N))); hold on
for j=1:length(a2)
    sz = ceil(100*abs(a2(j)));
    plot(X1(j),X2(j), 'r.',  'LineWidth', 2,'MarkerSize', min(50, sz));
end

for j=1:length(a_true)
    sz = (20*abs(a_true(j)));
    plot(X_true1(j),X_true2(j), 'kx',  'LineWidth', 2,'MarkerSize', sz);
end
% plot(X_true1(indp), X_true2(indp), 'k*', 'LineWidth', 2,  'MarkerSize', 10);

