function [x,a,R] = noncvx_sparse_spikes(op,lambda, x0,a0, x1,a1, options)

% [xf,af] = noncvx_sparse_spikes(op,x0,a0, x1,a1)
%
%   Solve 
%       min_{x,a} 1/(2*lambda)|Phi_x0*a0-Phi_x*a|^2 + |a|_1
%   using L-BFGS with initialization (x1,a1).
%
%   Set options.niter for BFGS #iterations.
%
%   Copyright (c) 2017 Gabriel Peyre

options.null = 0;

X = @(z)z(1:length(x1));
A = @(z)z(length(x1)+1:end);
XA = @(x,a)[x(:);a(:)];

z1 = XA(x1,a1);
Ebfgs = @(z)op.E(X(z),A(z),x0,a0,lambda);
nablaE = @(z)real( XA( op.nablaEx(X(z),A(z),x0,a0,lambda), op.nablaEa(X(z),A(z),x0,a0,lambda) ) );
% callback for L-BFGS
nablaEbfgs = @(z)deal(Ebfgs(z),nablaE(z));

options.report = @(z,v)v;
[z, R, info] = perform_bfgs(nablaEbfgs, z1, options);

x = X(z); a = A(z);

end