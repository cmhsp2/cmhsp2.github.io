%Stochastic ensemble Kalman filter for an anharmonic oscillator
clearvars
x0 = 0;
x1 = 1;
w = 0.03;
lambda = 0.0003;
u0 = [x0;x1];

H = [1 0];
uk = u0;
U = [];

Kmax = 1000;

P =10; %number of particles in ensemble Kalman filter

M = @(u) [(2+w^2-lambda^2*u(1)^2) -1; 1 0]*u;

%true states
for k=1:Kmax    
    uk = M(uk);
    U = [U,uk];    
end

%noisy observations
R = 7;
Y = H*U + sqrt(R)*randn(size(H*U));

%%
ave = @(u) sum(u,2)/(P);
cov0 = @(u) u*u'/(P-1);
cov = @(u) cov0(u - repmat(ave(u),[1,P]));

%initial background particles
var0 = 3;
uf = repmat([0;1],[1,P]) + sqrt(var0)*randn([2,P]);
Pf = cov(uf);


Ua =zeros(2,Kmax);
Uf = zeros(2,Kmax);

p=50; %frequency of observations
for k=1:Kmax
    if mod(k-1,p)==0
        y = Y(k);
        yu = sqrt(R)*randn([1,P]);    
        yt = repmat(y,1,P)+ yu;
        Ru = 1/(P-1)*sum(yu.^2);

        %analysis
        K = Pf*H'*inv(H*Pf *H'+ Ru);
        ua = uf + K*(yt-H*uf);
        Pa = cov(ua);  
    else
        ua = uf;
        Pa = Pf;
    end
    ua_bar =ave(ua);
    Ua(:,k) = ua_bar;

    %forecast
    for j=1:P
        uf(:,j) = M(ua(:,j));        
    end
    uf_bar =ave(uf);
    Pf = cov(uf);
    Uf(:,k) = uf_bar;   
    
end

%%
figure(3)
clf
hold on 

plot(H*U,'k-.', 'linewidth',2)
plot(H*Uf,'m', 'linewidth',1)
plot(1:p:Kmax, Y(1:p:Kmax), 'rx')

legend('ground truth', 'stochastic ensemble KF', 'observation points')

