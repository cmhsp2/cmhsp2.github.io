% Extended Kalman filter for an anharmonic oscillator

clearvars
x0 = 0;
x1 = 1;
w = 0.03;
lambda = 0.0003;
u0 = [x0;x1];

H = [1 0];
uk = u0;
U = [];

Kmax = 1000;

M = @(u) [(2+w^2-lambda^2*u(1)^2) -1; 1 0]*u;

%true states
for k=1:Kmax
    uk = M(uk);
    U = [U,uk];
end

%noisy observations
R = 7;
Y = H*U+sqrt(R)*randn(size(H*U));

%%
Ua =[]; %analysis states
Uf = []; %forecast states

%background state
sig0 = 5;
uf = [0;1] + sqrt(sig0)*randn();
Pf = sig0 *eye(2);

% % analysis
% K = Pf*H'*inv(H*Pf *H'+ R);
% ua1 = uf + K*(Y(1)-H*uf);
% Pa1 = (eye(2)-K*H)*Pf;
% Uf1 = [];
% uf1 = ua1;

p=50; 
for k=1:Kmax
    if mod(k-1,p)==0
        y = Y(k);        
        %analysis
        K = Pf*H'*inv(H*Pf *H'+ R);
        ua = uf + K*(y-H*uf);
        Pa = (eye(2)-K*H)*Pf;
    else
        ua = uf;
        Pa = Pf;
    end
    Ua = [Ua,ua];
    
    %forecast
    uf = M(ua);
    
    Mt = [(2+w^2-3*lambda^2*ua(1)^2) -1; 1 0]; %tangent linear of M
    Pf = Mt*Pa*Mt';
    Uf = [Uf,uf];
    
    
    
end
%%
figure(2)
clf
hold on
plot(H*U,'k-.', 'linewidth',2)
plot(H*Uf,'m', 'linewidth',1)
plot(1:p:Kmax, Y(1:p:Kmax), 'rx')

legend('ground truth', 'EKF approximation', 'observation points')
