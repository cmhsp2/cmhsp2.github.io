clear all
close all
clc
%% create signal 
% piecewise constant vector
x0 = 1 - [zeros(1,40), ones(1,60), zeros(1,60), ones(1,20), zeros(1,20),...
    zeros(1,50), ones(1,100), zeros(1,50), zeros(1,10), ones(1,60), zeros(1,30)];
n = length(x0);
% or one can use the following codes to generate a piecewise constant vector
% n = 128;
% x0 = sign(randn(1, n));
% rng = randperm(n); % Random permutation of [1,...,n]
% x0(rng(9:end)) = 0;
% x0 = cumsum(x0);

% generate a sparse noise
kappa = 16;
epsilon = 2* (rand(1, n) - 0.5);
rng = randperm(n); 
epsilon(rng(kappa+1:end)) = 0; 

f = x0 + epsilon;
%% parameters
L = 2; % norm of gradient operator
% \sigma\tau\|L\|^2 < 1
sigma = 1/L;
tau = 0.99/(sigma*L^2);

theta = 1.0; % relaxation parameter

para.tol = 5e-6;
para.maxits = 1e3;
%% TVL1 denoising
lambda = 1/1.5; % regularization parameter

[x, ek] = func_TVL1_denoising(f, lambda,sigma,tau,theta, para);

norm(x-x0)
%%
figure(101); % set(gcf, 'units','normalized', 'Position',[0.2 0.05 0.6 0.8]),
subplot(411), plot(x0, 'r', 'linewidth',1.5), title('original signal'); axis([1,n,min(x0)-0.1,max(x0)+0.1]); axis off;
subplot(412), plot(f, 'b', 'linewidth',1.5), title('noised signal'); axis([1,n,min(f)-0.1,max(f)+0.1]); axis off;
subplot(413), plot(x, 'k', 'linewidth',1.5), title('TVL1 denoised'); axis([1,n,min(x)-0.1,max(x)+0.1]); axis off;
subplot(414), plot(x-x0, 'b', 'linewidth',1.5), title('difference x-x0'); axis([1,n,min(x-x0)-0.1,max(x-x0)+0.1]); axis off;
%%