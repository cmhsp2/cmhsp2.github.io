function [x, ek] = func_TVL1_denoising(f, lambda, sigma,tau, theta, para)
% ANISOtropic TV

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[m, n] = size(f);
dh = @(x) [ diff(x,1,2), zeros(m,1) ];       % forward difference
dht = @(x) [ -x(:,1), -diff(x(:,1:n-1),1,2), x(:,n-1) ];      % transpose x-derivative
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
siglam = sigma /lambda;

x = f;
v = dh(x);
% v= f;

tol = para.tol; % stopping criteria
maxits = para.maxits; % max number of iteration

ek = zeros(1, maxits); % residual of primal variable

its = 1;
while(its < maxits)
    x_old = x;
    
    % primal update
    x = f + wthresh(x - sigma*dht(v) - f, 's', siglam);
    
    % relaxation
    xbar = x + theta*(x - x_old);
    
    % dual update
    v_tmp = v + tau* dh(xbar);
    v = v_tmp - tau* wthresh(v_tmp/tau, 's', 1/tau);
    
    % % stop?
    res = norm(x_old-x, 'fro');%/norm(x, 'fro');
    itsprint(sprintf('step %05d: norm(ek) = %.5e...', its, res), its);
    
    if (res<tol)||(res>1e10); break; end
    
    ek(its) = res;
    its = its + 1;
end
fprintf('\n');

ek = ek(1:its-1);

