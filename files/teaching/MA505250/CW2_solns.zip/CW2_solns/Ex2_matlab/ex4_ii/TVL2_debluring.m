clear all
close all
clc
%%
name = 'cameraman_256.png';
name = 'shepp_logan_phantom.png';
u0 = double(imread(name)); %original image


[m, n] = size(u0);

type = 'gaussian'; hsize = 11; sigma = 9;
h = fspecial(type, hsize, sigma);


f = ifft2( fft2(u0) .* fft2(h,m,n) ) + 2* randn(m, n); %noisy blurred observation

psnr0 = psnr(uint8(u0),uint8(f));
%% parameters
L = sqrt(8); % norm of gradient operator
% \sigma\tau\|L\|^2 < 1
sigma = 1/L;
tau = 0.99/(sigma*L^2);

theta = 1.0; % relaxation parameter

para.tol = 5e-6;
para.maxits = 5e2;
%% ANISOtropic TV
lambda = 1/5; % regularization parameter

[u1, ek1] = func_aTVL2_debluring(h,f, lambda,sigma,tau,theta, para);

psnr1 = psnr(uint8(u1), uint8(u0))
%% ISOtropic TV
lambda = 1/3;

[u2, ek2] = func_iTVL2_debluring(h,f, lambda,sigma,tau,theta, para);

psnr2 = psnr(uint8(u2), uint8(u0))
%%
figure(101), set(gcf, 'units','normalized', 'Position',[0.2 0.05 0.6 0.8]),
subplot(4,4,[1,2,5,6]), imgsc(u0), colormap('gray'), title('original image');
subplot(4,4,[3,4,7,8]), imgsc(f), colormap('gray'), title(['noised image, psnr=',num2str(psnr0)]);
subplot(4,4,[9,10,13,14]), imgsc(u1), colormap('gray'), title(['anisotropic TV recovered image, psnr=',num2str(psnr1)]);
subplot(4,4,[11,12,15,16]), imgsc(u2), colormap('gray'), title(['isotropic TV recovered image, psnr=',num2str(psnr2)]);

%% display the output
figure, set(gcf, 'units','normalized', 'Position',[0.2 0.05 0.6 0.8]),
subplot(1,9,[1:3]), imgsc(u0), colormap('gray'), title('original image');
subplot(1,9,[4:6]), imgsc(f), colormap('gray'), title(['blurred image, psnr=',num2str(psnr0)]);
subplot(1,9,[7:9]), imgsc(u2), colormap('gray'), title(['recovered image, psnr=',num2str(psnr2)]);
