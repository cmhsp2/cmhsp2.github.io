function [u, ek] = func_iTVL2_debluring(h,f, lambda, sigma,tau, theta, para)
% ANISOtropic TV

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[m, n] = size(f);
dh = @(x) [ diff(x,1,2), zeros(m,1) ];       % forward difference
dv = @(x) [ diff(x,1,1); zeros(1,n) ];       % discrete y-derivative
dht = @(x) [ -x(:,1), -diff(x(:,1:n-1),1,2), x(:,n-1) ];      % transpose x-derivative
dvt = @(x) [ -x(1,:); -diff(x(1:m-1,:),1,1); x(m-1,:) ];      % transpose y-derivative
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
F = fft2(f, m,n);
H = fft2(h, m,n);
conjH = conj(H);
FH = conjH .* F;
H2 = conjH .* H;

siglam = sigma /lambda;

u = f;
gh = dh(u);
gv = dv(u);

tol = para.tol; % stopping criteria
maxits = para.maxits; % max number of iteration

ek = zeros(1, maxits); % residual of primal variable

its = 1;
while(its < maxits)
    u_old = u;
    
    % primal update
    u_tmp = fft2(u - sigma*(dht(gh) + dvt(gv)));
    u = ifft2( (u_tmp + siglam*FH) ./ (1+siglam*H2) );
    
    % relaxation
    ubar = u + theta*(u - u_old);
    
    % dual update
    h_tmp = gh + tau* dh(ubar);
    v_tmp = gv + tau* dv(ubar);
    % g_tmp = sqrt(h_tmp.^2 + v_tmp.^2) /tau;
    % sg = max(1 - 1/tau./g_tmp, 0);
    sg = max(1 - 1./sqrt(h_tmp.^2 + v_tmp.^2), 0);
    sg_h = h_tmp/tau .* sg;
    sg_v = v_tmp/tau .* sg;
    gh = h_tmp - tau* sg_h;
    gv = v_tmp - tau* sg_v;
    
    % % stop?
    res = norm(u_old-u, 'fro')/norm(u, 'fro');
    itsprint(sprintf('step %05d: norm(ek) = %.5e...', its, res), its);
    
    if (res<tol)||(res>1e10); break; end
    
    ek(its) = res;
    its = its + 1;
end
fprintf('\n');

ek = ek(1:its-1);

