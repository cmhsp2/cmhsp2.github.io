% %load and display an image
im = phantom(256);
imagesc(im);
n = length(im);
%% define filter
x = [0:n/2-1, -n/2:-1];
[Y,X] = meshgrid(x,x);
s = 3; %kernel width in pixels
h = exp( (-X.^2-Y.^2)/(2*s^2) );
h = h/sum(h(:));

hF = real(fft2(h));

Phi = @(x,h)real(ifft2(fft2(x).*fft2(h))); %forward convolution operator


%% noisy measurements
y0 = Phi(im,h);
lambda =1e-16;
R1  = real( ifft2( fft2(y0) .* hF ./ ( abs(hF).^2 + lambda) ) );


%add noise
sigma = .05;
y = y0 + randn(n)*sigma;
figure(1)
imagesc(y); title('Noisy observation')
colormap gray

axis square

delta = norm(y(:) - y0(:))/norm(y(:)); %noise level
%% (a) Least squares solution is highly unstable
lambda = 1e-14;
yF = fft2(y);
lsq_rec = real( ifft2( yF .* hF ./ ( abs(hF).^2 + lambda) ) );
figure(2);
imagesc(lsq_rec);
title('Least squares solution under small noise')
%% (b) regularised solution Tikonov
yF = fft2(y);
lambda = 0.1;
tik_rec = real( ifft2( yF .* hF ./ ( abs(hF).^2 + lambda) ) );
figure(3);
imagesc(tik_rec);
title('Tikhonov regularised solution with \lambda = 0.1')
%% Test the discrepancy principle

lamb_vals = linspace(0.0001,1,1000);
lamb_vals = fliplr(lamb_vals);

eta = 1.5;
j=1;
discrep = delta*eta+1;
while  discrep > eta*delta
    lambda = lamb_vals(j);
    yF = fft2(y);
    fL2 = real( ifft2( yF .* hF ./ ( abs(hF).^2 + lambda) ) );
    
    Af = Phi(fL2,h);
    discrep = norm(y(:) - Af(:))/norm(y(:));
    
    j = j+1;
end



figure(4);
imagesc(fL2);
title(['u_\lambda via Mozorov discrepancy, \lambda', sprintf(' = %.3f',lambda)]);

