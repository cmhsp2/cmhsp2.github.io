[V, S, U] = svd(R, 'econ');
save(fullfile('results', 'ex5_svd.mat'), 'R', 'V', 'S', 'U');
%%
figure(1)
subplot(2, 3, 1), imagesc(reshape(V(:, 1), [95 90]))
axis image; colorbar; title('First singular vector v_1')
subplot(2, 3, 2), imagesc(reshape(V(:, 4), [95 90]))
axis image; colorbar; title('Fourth singular vector v_4')
subplot(2, 3, 3), imagesc(reshape(V(:, 12), [95 90]))
axis image; colorbar; title('Twelfth singular vector v_{12}')
subplot(2, 3, 4), imagesc(reshape(V(:, 30), [95 90]))
axis image; colorbar; title('30th singular vector v_{30}')
subplot(2, 3, 5), imagesc(reshape(V(:, 100), [95 90]))
axis image; colorbar; title('100th singular vector v_{100}')
subplot(2, 3, 6), imagesc(reshape(V(:, 1000), [95 90]))
axis image; colorbar; title('1000th singular vector v_{1000}')

% Save the results as png file.
mkdir('results');
saveas(gcf, fullfile('results', 'ex5ci.png'));

figure(2)
subplot(2, 3, 1), imagesc(reshape(U(:, 1), [64 64]))
axis image; colorbar; title('First singular vector u_1')
subplot(2, 3, 2), imagesc(reshape(U(:, 4), [64 64]))
axis image; colorbar; title('Fourth singular vector u_4')
subplot(2, 3, 3), imagesc(reshape(U(:, 12), [64 64]))
axis image; colorbar; title('Twelfth singular vector u_{12}')
subplot(2, 3, 4), imagesc(reshape(U(:, 20), [64 64]))
axis image; colorbar; title('20th singular vector u_{20}')
subplot(2, 3, 5), imagesc(reshape(U(:, 100), [64 64]))
axis image; colorbar; title('100th singular vector u_{100}')
subplot(2, 3, 6), imagesc(reshape(U(:, 1000), [64 64]))
axis image; colorbar; title('1000th singular vector u_{1000}')

% Save the results as png file.
mkdir('results');
saveas(gcf, fullfile('results', 'ex5cii.png'));