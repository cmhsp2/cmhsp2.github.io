R = zeros(95*90, 64^2);
w = waitbar(0,'Building Radon matrix');
for i=1:64^2
    e = zeros(64^2, 1);
    e(i) = 1;
    R(:, i) = reshape(radon(reshape(e, [64 64]), (0:2:178)), [95*90 1]);
    waitbar(i/(64^2))
end
close(w)