udagger = imresize(phantom, [64 64], 'nearest');
f = reshape(R*udagger(:), [95 90]);
sigma = [0.1; 0.5; 1; 3; 5];
d = numel(sigma);
fdelta = reshape(f(:)*ones(1, numel(sigma)) + abs(randn(numel(f), ...
    d))*spdiags(sigma, 0, numel(sigma), d), [size(f) d]);