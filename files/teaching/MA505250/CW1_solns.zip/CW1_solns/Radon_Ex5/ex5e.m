g = @(alpha) diag(S)./(diag(S.^2) + alpha);

singvalinv = g(0);
Rinv = U*diag(singvalinv)*V';
u0 = reshape(Rinv*reshape(fdelta, [95*90 5]), [64 64 5]);

singvalinv = g(0.01);
Rinv = U*diag(singvalinv)*V';
u1 = reshape(Rinv*reshape(fdelta, [95*90 5]), [64 64 5]);

singvalinv = g(1);
Rinv = U*diag(singvalinv)*V';
u2 = reshape(Rinv*reshape(fdelta, [95*90 5]), [64 64 5]);

singvalinv = g(10);
Rinv = U*diag(singvalinv)*V';
u3 = reshape(Rinv*reshape(fdelta, [95*90 5]), [64 64 5]);

singvalinv = g(100);
Rinv = U*diag(singvalinv)*V';
u4 = reshape(Rinv*reshape(fdelta, [95*90 5]), [64 64 5]);

singvalinv = g(1000);
Rinv = U*diag(singvalinv)*V';
u5 = reshape(Rinv*reshape(fdelta, [95*90 5]), [64 64 5]);

%% show the results
figure(2); 
subplot(236); imagesc(u0(:,:,1)); axis image; colorbar; title('alpha=0');
subplot(235); imagesc(u1(:,:,1)); axis image; colorbar; title('alpha=0.01');
subplot(234); imagesc(u2(:,:,1)); axis image; colorbar; title('alpha=1');
subplot(233); imagesc(u3(:,:,1)); axis image; colorbar; title('alpha=10');
subplot(232); imagesc(u4(:,:,1)); axis image; colorbar; title('alpha=100');
subplot(231); imagesc(u5(:,:,1)); axis image; colorbar; title('alpha=1000');

% Save the results as png file.
mkdir('results');
saveas(gcf, fullfile('results', 'ex5e.png'));