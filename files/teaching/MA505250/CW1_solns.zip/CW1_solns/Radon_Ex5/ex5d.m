% Don't truncate
singvaltruncinv = 1./diag(S);
Rinv = U*diag(singvaltruncinv)*V';
utsvd0 = reshape(Rinv*reshape(fdelta, [95*90 5]), [64 64 5]);

% Truncate all singular values below 0.01
singvaltruncinv = 1./diag(S);
singvaltruncinv(diag(S) < 0.01) = 0;
Rinv = U*diag(singvaltruncinv)*V';
utsvd1 = reshape(Rinv*reshape(fdelta, [95*90 5]), [64 64 5]);

% Truncate all singular values below 0.1
singvaltruncinv = 1./diag(S);
singvaltruncinv(diag(S) < 0.1) = 0;
Rinv = U*diag(singvaltruncinv)*V';
utsvd2 = reshape(Rinv*reshape(fdelta, [95*90 5]), [64 64 5]);

% Truncate all singular values below 0.5
singvaltruncinv = 1./diag(S);
singvaltruncinv(diag(S) < 0.5) = 0;
Rinv = U*diag(singvaltruncinv)*V';
utsvd3 = reshape(Rinv*reshape(fdelta, [95*90 5]), [64 64 5]);

% Truncate all singular values below 5
singvaltruncinv = 1./diag(S);
singvaltruncinv(diag(S) < 5) = 0;
Rinv = U*diag(singvaltruncinv)*V';
utsvd4 = reshape(Rinv*reshape(fdelta, [95*90 5]), [64 64 5]);

% Truncate all singular values below 10
singvaltruncinv = 1./diag(S);
singvaltruncinv(diag(S) < 10) = 0;
Rinv = U*diag(singvaltruncinv)*V';
utsvd5 = reshape(Rinv*reshape(fdelta, [95*90 5]), [64 64 5]);

%% show the results
figure(1); 
subplot(236); imagesc(utsvd0(:,:,1)); axis image; colorbar; title('no thresh');
subplot(235); imagesc(utsvd1(:,:,1)); axis image; colorbar; title('thresh=0.01');
subplot(234); imagesc(utsvd2(:,:,1)); axis image; colorbar; title('thresh=0.1');
subplot(233); imagesc(utsvd3(:,:,1)); axis image; colorbar; title('thresh=0.5');
subplot(232); imagesc(utsvd4(:,:,1)); axis image; colorbar; title('thresh=5');
subplot(231); imagesc(utsvd5(:,:,1)); axis image; colorbar; title('thresh=10');

% Save the results as png file.
mkdir('results');
saveas(gcf, fullfile('results', 'ex5d.png'));